sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("projectempui.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  