/* global QUnit */

sap.ui.require(["projectempui/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
