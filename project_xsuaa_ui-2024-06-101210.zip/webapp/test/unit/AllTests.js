sap.ui.define([
	"sapbtp/project_xsuaa_ui/test/unit/controller/Page1.controller"
], function () {
	"use strict";
});
