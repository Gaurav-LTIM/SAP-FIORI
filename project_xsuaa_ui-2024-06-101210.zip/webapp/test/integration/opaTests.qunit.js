/* global QUnit */

sap.ui.require(["sap/btp/projectxsuaaui/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
